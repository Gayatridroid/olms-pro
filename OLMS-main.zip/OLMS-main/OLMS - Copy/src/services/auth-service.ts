import { prisma } from "@/prisma/client";
import { createAccessToken, createRefreshToken, hashToken, verifyHashedToken, type SessionUser } from "@/lib/auth";

export async function registerUser(data: {
  name: string;
  email: string;
  password: string;
  phone: string;
}) {
  const existing = await prisma.user.findUnique({ where: { email: data.email } });
  if (existing) {
    throw new Error("Email already registered");
  }

  const hashedPassword = await hashToken(data.password);
  const user = await prisma.user.create({
    data: {
      name: data.name,
      email: data.email,
      phone: data.phone,
      hashedPassword,
      role: {
        connectOrCreate: {
          where: { name: "RECRUITER" },
          create: { name: "RECRUITER" },
        },
      },
    },
    select: {
      id: true,
      email: true,
      name: true,
      departmentId: true,
      role: {
        select: {
          name: true,
        },
      },
    },
  });

  return {
    id: user.id,
    email: user.email,
    name: user.name,
    departmentId: user.departmentId,
    role: user.role.name,
  };
}

export async function authenticateUser(email: string, password: string) {
  const user = await prisma.user.findUnique({
    where: { email },
    include: {
      role: {
        select: {
          name: true,
        },
      },
    },
  });

  if (!user) {
    return null;
  }

  const valid = await verifyHashedToken(password, user.hashedPassword);
  if (!valid) {
    return null;
  }

  const sessionUser: SessionUser = {
    id: user.id,
    email: user.email,
    name: user.name,
    role: user.role.name,
    departmentId: user.departmentId,
  };

  return sessionUser;
}

export async function createUserTokens(user: SessionUser) {
  const accessToken = createAccessToken(user);
  const refreshToken = createRefreshToken(user);
  const hashedRefresh = await hashToken(refreshToken);

  await prisma.user.update({
    where: { id: user.id },
    data: { refreshToken: hashedRefresh },
  });

  return { accessToken, refreshToken };
}
