import nodemailer from 'nodemailer';
import type { SendMailOptions } from 'nodemailer';
import { prisma } from '@/prisma/client';
import { decryptValue } from '@/lib/crypto';
import { getSettings } from '@/services/settings-service';
import { buildEmailHtml, buildPlainTextEmail, EmailTemplateProps } from '@/services/email-templates';
import { recordEmailLog, hasEmailEventBeenSent } from '@/services/email-log-service';
import type { OfferDetail } from '@/types/offer';

const transporterCache: { transport: nodemailer.Transporter | null } = { transport: null };

function normalizeHost(value: string | null | undefined) {
  return value?.trim() || undefined;
}

async function createTransporter() {
  if (transporterCache.transport) {
    return transporterCache.transport;
  }

  const settings = await getSettings();
  const rawSettings = await prisma.appSetting.findFirst();
  const host = normalizeHost(settings.smtpHost) || process.env.MAILTRAP_HOST;
  const port = settings.smtpPort ?? (process.env.MAILTRAP_PORT ? Number(process.env.MAILTRAP_PORT) : 2525);
  const user = settings.smtpUser || process.env.MAILTRAP_USER;
  const pass = rawSettings?.smtpPasswordEncrypted ? decryptValue(rawSettings.smtpPasswordEncrypted) : process.env.MAILTRAP_PASS;

  if (!host || !port || !user || !pass) {
    throw new Error('SMTP configuration is incomplete. Set SMTP credentials in settings or use Mailtrap environment variables.');
  }

  const transport = nodemailer.createTransport({
    host,
    port,
    secure: settings.smtpSecure !== false,
    auth: {
      user,
      pass,
    },
  });

  transporterCache.transport = transport;
  return transport;
}

function createFromAddress(settings: Awaited<ReturnType<typeof getSettings>>) {
  const fromAddress = settings.smtpFromEmail || `no-reply@${settings.companyName?.replace(/\s+/g, '').toLowerCase() || 'olms'}.com`;
  const fromName = settings.smtpFromName || settings.companyName || 'OLMS';
  return `${fromName} <${fromAddress}>`;
}

export type EmailSendRequest = {
  recipient: string;
  recipientName: string;
  subject: string;
  html: string;
  text: string;
  eventKey?: string;
  entityId?: string;
  metadata?: Record<string, unknown>;
};

export async function sendEmail(request: EmailSendRequest) {
  const settings = await getSettings();
  const transport = await createTransporter();
  const from = createFromAddress(settings);

  if (request.eventKey && request.entityId) {
    const alreadySent = await hasEmailEventBeenSent(request.recipient, request.eventKey, request.entityId);
    if (alreadySent) {
      return;
    }
  }

  const mailOptions: SendMailOptions = {
    from,
    to: request.recipient,
    subject: request.subject,
    html: request.html,
    text: request.text,
  };

  try {
    const result = await transport.sendMail(mailOptions);

    await recordEmailLog({
      recipient: request.recipient,
      subject: request.subject,
      status: 'SENT',
      eventKey: request.eventKey ?? null,
      entityId: request.entityId ?? null,
      details: { accepted: result.accepted, rejected: result.rejected, messageId: result.messageId },
    });

    return result;
  } catch (error) {
    await recordEmailLog({
      recipient: request.recipient,
      subject: request.subject,
      status: 'FAILED',
      eventKey: request.eventKey ?? null,
      entityId: request.entityId ?? null,
      details: { error: error instanceof Error ? error.message : String(error) },
    });

    throw error;
  }
}

export async function queueTransactionalEmail(request: EmailSendRequest) {
  const { enqueueEmail } = await import('./email-queue');
  await enqueueEmail(request);
}

export async function sendOfferCreatedEmail(offer: OfferDetail, recipientName: string, recipientEmail: string, ctaUrl: string) {
  const template = buildEmailHtml({
    companyName: offer.departmentName,
    recipientName,
    subject: `Offer created: ${offer.title}`,
    heading: `New offer created for ${offer.candidateName}`,
    body: `Your offer ${offer.title} has been created and is ready for the next approval and release step.`,
    ctaText: 'View offer',
    ctaUrl,
    previewText: `Offer created for ${offer.candidateName}`,
  });

  await queueTransactionalEmail({
    recipient: recipientEmail,
    recipientName,
    subject: `Offer created: ${offer.title}`,
    html: template,
    text: buildPlainTextEmail({
      companyName: offer.departmentName,
      recipientName,
      subject: `Offer created: ${offer.title}`,
      heading: `New offer created for ${offer.candidateName}`,
      body: `Your offer ${offer.title} has been created and is ready for the next approval and release step.`,
      ctaText: 'View offer',
      ctaUrl,
    }),
    eventKey: 'OFFER_CREATED',
    entityId: offer.id,
  });
}

export async function sendApprovalRequestEmail(offer: OfferDetail, recipientName: string, recipientEmail: string, ctaUrl: string) {
  const template = buildEmailHtml({
    companyName: offer.departmentName,
    recipientName,
    subject: `Approval requested: ${offer.title}`,
    heading: `Approval required for ${offer.title}`,
    body: `A new approval request is waiting for your review for candidate ${offer.candidateName}. Please approve or reject the offer before the workflow window closes.`,
    ctaText: 'Review approval',
    ctaUrl,
    previewText: `Approval requested for ${offer.candidateName}`,
  });

  await queueTransactionalEmail({
    recipient: recipientEmail,
    recipientName,
    subject: `Approval requested: ${offer.title}`,
    html: template,
    text: buildPlainTextEmail({
      companyName: offer.departmentName,
      recipientName,
      subject: `Approval requested: ${offer.title}`,
      heading: `Approval required for ${offer.title}`,
      body: `A new approval request is waiting for your review for candidate ${offer.candidateName}.`,
      ctaText: 'Review approval',
      ctaUrl,
    }),
    eventKey: 'OFFER_APPROVAL_REQUESTED',
    entityId: offer.id,
  });
}

export async function sendApprovalCompletedEmail(offer: OfferDetail, decision: string, recipientName: string, recipientEmail: string, ctaUrl: string) {
  const template = buildEmailHtml({
    companyName: offer.departmentName,
    recipientName,
    subject: `Approval ${decision.toLowerCase()}: ${offer.title}`,
    heading: `Approval ${decision.toLowerCase()} for ${offer.title}`,
    body: `The approval workflow for ${offer.candidateName} has been ${decision.toLowerCase()}. Review the updated offer details in the workflow dashboard.`,
    ctaText: 'View offer',
    ctaUrl,
    previewText: `Approval ${decision.toLowerCase()} for ${offer.candidateName}`,
  });

  await queueTransactionalEmail({
    recipient: recipientEmail,
    recipientName,
    subject: `Approval ${decision.toLowerCase()}: ${offer.title}`,
    html: template,
    text: buildPlainTextEmail({
      companyName: offer.departmentName,
      recipientName,
      subject: `Approval ${decision.toLowerCase()}: ${offer.title}`,
      heading: `Approval ${decision.toLowerCase()} for ${offer.title}`,
      body: `The approval workflow for ${offer.candidateName} has been ${decision.toLowerCase()}.`,
      ctaText: 'View offer',
      ctaUrl,
    }),
    eventKey: `OFFER_APPROVAL_${decision.toUpperCase()}`,
    entityId: offer.id,
  });
}

export async function sendOfferStatusNotificationEmail(offer: OfferDetail, status: string, recipientName: string, recipientEmail: string, ctaUrl: string) {
  const template = buildEmailHtml({
    companyName: offer.departmentName,
    recipientName,
    subject: `Offer ${status.toLowerCase()}: ${offer.title}`,
    heading: `Offer ${status.toLowerCase()} for ${offer.title}`,
    body: `The offer for ${offer.candidateName} has been ${status.toLowerCase()}. Review the workflow details and next steps on your dashboard.`,
    ctaText: 'View offer',
    ctaUrl,
    previewText: `Offer ${status.toLowerCase()} for ${offer.candidateName}`,
  });

  await queueTransactionalEmail({
    recipient: recipientEmail,
    recipientName,
    subject: `Offer ${status.toLowerCase()}: ${offer.title}`,
    html: template,
    text: buildPlainTextEmail({
      companyName: offer.departmentName,
      recipientName,
      subject: `Offer ${status.toLowerCase()}: ${offer.title}`,
      heading: `Offer ${status.toLowerCase()} for ${offer.title}`,
      body: `The offer for ${offer.candidateName} has been ${status.toLowerCase()}.`,
      ctaText: 'View offer',
      ctaUrl,
    }),
    eventKey: `OFFER_${status.toUpperCase()}`,
    entityId: offer.id,
  });
}

export async function sendOfferExpiringEmail(offer: OfferDetail, recipientName: string, recipientEmail: string, ctaUrl: string) {
  const template = buildEmailHtml({
    companyName: offer.departmentName,
    recipientName,
    subject: `Offer expiring soon: ${offer.title}`,
    heading: `Offer expiring within 72 hours`,
    body: `The offer for ${offer.candidateName} is approaching its expiration date. Review the details and act quickly to keep the workflow on track.`,
    ctaText: 'View expiring offer',
    ctaUrl,
    previewText: `Offer expiring soon for ${offer.candidateName}`,
  });

  await queueTransactionalEmail({
    recipient: recipientEmail,
    recipientName,
    subject: `Offer expiring soon: ${offer.title}`,
    html: template,
    text: buildPlainTextEmail({
      companyName: offer.departmentName,
      recipientName,
      subject: `Offer expiring soon: ${offer.title}`,
      heading: `Offer expiring within 72 hours`,
      body: `The offer for ${offer.candidateName} is approaching its expiration date.`,
      ctaText: 'View expiring offer',
      ctaUrl,
    }),
    eventKey: 'OFFER_EXPIRING',
    entityId: offer.id,
  });
}

export async function sendReminderEmail(title: string, message: string, companyName: string, recipientName: string, recipientEmail: string, ctaUrl: string, entityId: string) {
  const template = buildEmailHtml({
    companyName,
    recipientName,
    subject: title,
    heading: title,
    body: message,
    ctaText: 'Review reminder',
    ctaUrl,
    previewText: message,
  });

  await queueTransactionalEmail({
    recipient: recipientEmail,
    recipientName,
    subject: title,
    html: template,
    text: buildPlainTextEmail({
      companyName,
      recipientName,
      subject: title,
      heading: title,
      body: message,
      ctaText: 'Review reminder',
      ctaUrl,
    }),
    eventKey: `REMINDER_${entityId}`,
    entityId,
  });
}
