import { OfferDetail } from '@/types/offer';
import { formatCurrency } from '@/lib/utils';

export type EmailTemplateProps = {
  companyName: string;
  recipientName: string;
  subject: string;
  heading: string;
  body: string;
  ctaText?: string;
  ctaUrl?: string;
  previewText?: string;
};

const safe = (value: string) => value || '';

export function buildEmailHtml(props: EmailTemplateProps) {
  const brand = props.companyName || 'OLMS';
  const preview = safe(props.previewText || `${props.heading} — ${props.body}`);

  return `<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>${safe(props.subject)}</title>
    <style>
      body { margin: 0; padding: 0; background-color: #0f172a; color: #e2e8f0; font-family: Inter, system-ui, sans-serif; }
      .container { width: 100%; padding: 24px 0; background-color: #0f172a; }
      .card { max-width: 680px; margin: 0 auto; background: linear-gradient(180deg, rgba(15,23,42,0.98), rgba(15,23,42,1)); border: 1px solid rgba(148,163,184,0.12); border-radius: 24px; box-shadow: 0 20px 80px rgba(15,23,42,0.45); }
      .inner { padding: 32px; }
      .header { display: flex; align-items: center; justify-content: space-between; margin-bottom: 32px; }
      .brand { font-size: 0.9rem; letter-spacing: 0.16em; text-transform: uppercase; color: #38bdf8; }
      .title { font-size: 2rem; line-height: 1.15; color: #ffffff; margin: 0; }
      .body { margin-top: 24px; color: #cbd5e1; line-height: 1.75; font-size: 1rem; }
      .button { display: inline-flex; align-items: center; justify-content: center; margin-top: 32px; padding: 14px 24px; background: #38bdf8; color: #0f172a; border-radius: 9999px; text-decoration: none; font-weight: 700; }
      .footer { margin-top: 40px; color: #94a3b8; font-size: 0.95rem; line-height: 1.7; }
      .panel { margin-top: 24px; padding: 20px; border: 1px solid rgba(148,163,184,0.12); border-radius: 18px; background: rgba(15,23,42,0.9); }
      .panel strong { color: #ffffff; }
      @media (max-width: 600px) { .inner { padding: 24px; } .title { font-size: 1.75rem; } }
    </style>
  </head>
  <body>
    <div class="container">
      <div class="card" role="article" aria-label="${safe(props.subject)}">
        <div class="inner">
          <div class="header">
            <div class="brand">${brand}</div>
          </div>
          <h1 class="title">${safe(props.heading)}</h1>
          <div class="body">${safe(props.body).replace(/\n/g, '<br />')}</div>
          ${props.ctaText && props.ctaUrl ? `<a href="${props.ctaUrl}" class="button">${safe(props.ctaText)}</a>` : ''}
          <div class="footer">
            <p>If you did not expect this email, you can safely ignore it.</p>
            <p>${brand} automation engine</p>
          </div>
        </div>
      </div>
    </div>
  </body>
</html>`;
}

export function buildPlainTextEmail(props: EmailTemplateProps) {
  const cta = props.ctaText && props.ctaUrl ? `\n\n${props.ctaText}: ${props.ctaUrl}` : '';
  return `${props.subject}\n\n${props.heading}\n\n${props.body}${cta}\n\n${props.companyName}`;
}

export function buildOfferCreatedTemplate(offer: OfferDetail, companyName: string, recipientName: string, ctaUrl: string) {
  const subject = `Offer created: ${offer.title}`;
  const heading = `New offer created for ${offer.candidateName}`;
  const body = `Your offer ${offer.title} for ${offer.candidateName} has been created and is scheduled for review. You can manage approvals and release details from the workflow dashboard.`;

  return {
    subject,
    html: buildEmailHtml({ companyName, recipientName, subject, heading, body, ctaText: 'View offer', ctaUrl }),
    text: buildPlainTextEmail({ companyName, recipientName, subject, heading, body, ctaText: 'View offer', ctaUrl }),
  };
}

export function buildApprovalRequestTemplate(offer: OfferDetail, companyName: string, recipientName: string, ctaUrl: string) {
  const subject = `Approval requested: ${offer.title}`;
  const heading = `Approval required for ${offer.title}`;
  const body = `A new approval request has been submitted for ${offer.candidateName} in ${offer.departmentName}. Please review the offer details and take action before the approval window closes.`;

  return {
    subject,
    html: buildEmailHtml({ companyName, recipientName, subject, heading, body, ctaText: 'Review approval', ctaUrl }),
    text: buildPlainTextEmail({ companyName, recipientName, subject, heading, body, ctaText: 'Review approval', ctaUrl }),
  };
}

export function buildApprovalCompletedTemplate(offer: OfferDetail, companyName: string, recipientName: string, decision: string, ctaUrl: string) {
  const subject = `Approval ${decision.toLowerCase()}: ${offer.title}`;
  const heading = `Approval ${decision.toLowerCase()} for ${offer.title}`;
  const body = `The approval workflow for ${offer.candidateName} has been marked ${decision.toLowerCase()}. Review the updated offer status and next steps in the workflow dashboard.`;

  return {
    subject,
    html: buildEmailHtml({ companyName, recipientName, subject, heading, body, ctaText: 'View offer', ctaUrl }),
    text: buildPlainTextEmail({ companyName, recipientName, subject, heading, body, ctaText: 'View offer', ctaUrl }),
  };
}

export function buildOfferReleasedTemplate(offer: OfferDetail, companyName: string, recipientName: string, ctaUrl: string) {
  const subject = `Offer released: ${offer.title}`;
  const heading = `Your offer is ready for candidate review`;
  const body = `The offer for ${offer.candidateName} has been released and is ready for candidate acceptance. Keep the workflow moving by tracking candidate responses from the offer dashboard.`;

  return {
    subject,
    html: buildEmailHtml({ companyName, recipientName, subject, heading, body, ctaText: 'View released offer', ctaUrl }),
    text: buildPlainTextEmail({ companyName, recipientName, subject, heading, body, ctaText: 'View released offer', ctaUrl }),
  };
}

export function buildOfferStatusUpdateTemplate(offer: OfferDetail, companyName: string, recipientName: string, decision: string, ctaUrl: string) {
  const subject = `Offer ${decision.toLowerCase()}: ${offer.title}`;
  const heading = `Offer ${decision.toLowerCase()} for ${offer.candidateName}`;
  const body = `The offer for ${offer.candidateName} has been ${decision.toLowerCase()}. Review the final workflow notes and take any follow-up actions from the dashboard.`;

  return {
    subject,
    html: buildEmailHtml({ companyName, recipientName, subject, heading, body, ctaText: 'View offer', ctaUrl }),
    text: buildPlainTextEmail({ companyName, recipientName, subject, heading, body, ctaText: 'View offer', ctaUrl }),
  };
}

export function buildOfferExpiringTemplate(offer: OfferDetail, companyName: string, recipientName: string, ctaUrl: string) {
  const subject = `Offer expiring soon: ${offer.title}`;
  const heading = `Offer expiring within 72 hours`;
  const body = `The pending offer for ${offer.candidateName} will expire soon. Review the workflow and take any necessary action to keep the offer on schedule.`;

  return {
    subject,
    html: buildEmailHtml({ companyName, recipientName, subject, heading, body, ctaText: 'View offer', ctaUrl }),
    text: buildPlainTextEmail({ companyName, recipientName, subject, heading, body, ctaText: 'View offer', ctaUrl }),
  };
}

export function buildReminderTemplate(title: string, message: string, companyName: string, recipientName: string, ctaUrl: string) {
  const subject = `Reminder: ${title}`;
  const heading = title;
  const body = message;

  return {
    subject,
    html: buildEmailHtml({ companyName, recipientName, subject, heading, body, ctaText: 'Review reminder', ctaUrl }),
    text: buildPlainTextEmail({ companyName, recipientName, subject, heading, body, ctaText: 'Review reminder', ctaUrl }),
  };
}

export function buildOnboardingTemplate(offer: OfferDetail, companyName: string, recipientName: string, ctaUrl: string) {
  const subject = `Welcome aboard: ${offer.candidateName}`;
  const heading = `New hire onboarding triggered`;
  const body = `The offer for ${offer.candidateName} has been accepted. Start the onboarding workflow and welcome the new hire to ${companyName}.`;

  return {
    subject,
    html: buildEmailHtml({ companyName, recipientName, subject, heading, body, ctaText: 'View onboarding', ctaUrl }),
    text: buildPlainTextEmail({ companyName, recipientName, subject, heading, body, ctaText: 'View onboarding', ctaUrl }),
  };
}
