'use client';

import { useState } from "react";
import { useRouter } from "next/navigation";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { signupSchema } from "@/validators/auth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { setAccessToken } from "@/lib/auth-client";
import { useToast } from "@/components/ui/toast";
import { useAuthStore } from "@/store/use-auth-store";
import { z } from "zod";

const schema = signupSchema;

type SignupFormValues = z.infer<typeof schema>;

export function SignupForm() {
  const router = useRouter();
  const [error, setError] = useState<string | null>(null);
  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
  } = useForm<SignupFormValues>({ resolver: zodResolver(schema) });

  const setUser = useAuthStore((state) => state.setUser);
  const { toast } = useToast();

  async function onSubmit(values: SignupFormValues) {
    setError(null);

    const response = await fetch("/api/auth/signup", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(values),
    });

    if (!response.ok) {
      const payload = await response.json();
      setError(payload.error || "Unable to create account");
      return;
    }

    const payload = await response.json();
    setAccessToken(payload.accessToken);
    setUser(payload.user);
    toast({
      title: "Account created",
      description: "Your OLMS account is ready to use.",
      variant: "success",
    });
    router.push("/");
    router.refresh();
  }

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-5 rounded-[32px] bg-slate-950/90 p-8 shadow-2xl shadow-slate-950/40 ring-1 ring-slate-800/60">
      <div className="space-y-2">
        <h1 className="text-3xl font-semibold text-white">Create your account</h1>
        <p className="text-sm text-slate-400">Register a secure HRMS account and begin managing offers, candidates, and approvals.</p>
      </div>

      <div className="grid gap-4 sm:grid-cols-2">
        <div className="space-y-4">
          <label className="block text-sm font-medium text-slate-300">Full name</label>
          <Input placeholder="Avery Chen" {...register("name")} />
          {errors.name && <p className="text-sm text-rose-400">{errors.name.message}</p>}
        </div>
        <div className="space-y-4">
          <label className="block text-sm font-medium text-slate-300">Phone</label>
          <Input type="tel" placeholder="(555) 123-4567" {...register("phone")} />
          {errors.phone && <p className="text-sm text-rose-400">{errors.phone.message}</p>}
        </div>
      </div>

      <div className="space-y-4">
        <label className="block text-sm font-medium text-slate-300">Email</label>
        <Input type="email" autoComplete="email" placeholder="hello@company.com" {...register("email")} />
        {errors.email && <p className="text-sm text-rose-400">{errors.email.message}</p>}
      </div>

      <div className="space-y-4">
        <label className="block text-sm font-medium text-slate-300">Password</label>
        <Input type="password" autoComplete="new-password" placeholder="********" {...register("password")} />
        {errors.password && <p className="text-sm text-rose-400">{errors.password.message}</p>}
      </div>

      {error && <p className="rounded-3xl bg-rose-500/10 p-3 text-sm text-rose-300">{error}</p>}

      <Button type="submit" disabled={isSubmitting} className="w-full">
        {isSubmitting ? "Creating account..." : "Sign up"}
      </Button>
    </form>
  );
}
